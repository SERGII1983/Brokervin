# 📬 Налаштування відправки форми в Telegram та Email

## 🤖 Налаштування Telegram Bot

### Крок 1: Створення бота

1. Відкрийте Telegram та знайдіть бота **@BotFather**
2. Відправте команду `/newbot`
3. Введіть назву бота (наприклад: "Broker VN Notifications")
4. Введіть username бота (має закінчуватися на "bot", наприклад: "brokervn_notifications_bot")
5. **Збережіть Bot Token** який надасть BotFather (виглядає як: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### Крок 2: Отримання Chat ID

**Варіант 1 - Особистий чат:**
1. Напишіть щось вашому боту (наприклад: "Привіт")
2. Відкрийте в браузері: `https://api.telegram.org/bot<ВАШ_BOT_TOKEN>/getUpdates`
3. Знайдіть `"chat":{"id":123456789}` - це ваш Chat ID

**Варіант 2 - Група/Канал:**
1. Додайте бота в групу/канал
2. Зробіть бота адміністратором
3. Напишіть щось в групі
4. Відкрийте: `https://api.telegram.org/bot<ВАШ_BOT_TOKEN>/getUpdates`
5. Знайдіть Chat ID (для груп починається з `-`)

### Крок 3: Вставка в код

Відкрийте файл `js/script.js` та знайдіть:

```javascript
const TELEGRAM_BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE'; // Замінити на свій токен
const TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID_HERE';     // Замінити на свій Chat ID
```

Замініть на ваші дані:

```javascript
const TELEGRAM_BOT_TOKEN = '1234567890:ABCdefGHIjklMNOpqrsTUVwxyz';
const TELEGRAM_CHAT_ID = '123456789'; // або '-123456789' для груп
```

### Крок 4: Увімкнення відправки

Знайдіть закоментований блок коду:

```javascript
/*
try {
    const telegramResponse = await fetch(...
    ...
} catch (error) {
    ...
}
*/
```

**Видаліть коментарі** `/*` та `*/` щоб увімкнути відправку.

---

## 📧 Налаштування Email (FormSubmit)

FormSubmit.co - безкоштовний сервіс для відправки форм на email без backend.

### Варіант 1: Просте налаштування (Рекомендується)

1. Відкрийте `js/script.js`
2. Знайдіть закоментований блок з FormSubmit
3. Видаліть коментарі `/*` та `*/`
4. Email вже вказаний: `brokervinnitsa@gmail.com`

**Перша відправка:**
- FormSubmit надішле лист підтвердження на `brokervinnitsa@gmail.com`
- Підтвердіть email, клікнувши по посиланню
- Після підтвердження всі наступні відправки працюватимуть автоматично

### Варіант 2: З додатковими налаштуваннями

```javascript
const emailResponse = await fetch('https://formsubmit.co/brokervinnitsa@gmail.com', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    body: JSON.stringify({
        name: name,
        phone: phone,
        message: message,
        _subject: '🔔 Нове замовлення дзвінка - Brokervn.com.ua',
        _captcha: 'false',        // Вимкнути captcha
        _template: 'table',        // Формат листа
        _cc: 'додатковий@email.com' // Копія на інший email (опціонально)
    })
});
```

### Варіант 3: Інші сервіси

**EmailJS:**
1. Зареєструйтесь на https://www.emailjs.com/
2. Створіть Email Service
3. Отримайте Service ID, Template ID, User ID
4. Додайте в код:

```javascript
emailjs.send(
    'service_id',
    'template_id',
    {
        from_name: name,
        phone: phone,
        message: message
    },
    'user_id'
);
```

---

## ✅ Швидке налаштування (5 хвилин)

### Для Telegram:
1. Створіть бота в @BotFather → отримайте токен
2. Напишіть боту → отримайте Chat ID через getUpdates
3. Вставте в `js/script.js`
4. Розкоментуйте код відправки

### Для Email:
1. Розкоментуйте блок FormSubmit в `js/script.js`
2. Підтвердіть email при першій відправці
3. Готово!

---

## 🧪 Тестування

1. Відкрийте сайт у браузері
2. Натисніть "Отримати консультацію"
3. Заповніть форму
4. Натисніть "Замовити дзвінок"
5. Перевірте:
   - Консоль браузера (F12) - дані мають з'явитися
   - Telegram - повідомлення від бота
   - Email - лист на brokervinnitsa@gmail.com

---

## 📝 Формат повідомлення

Telegram та Email отримають:

```
🔔 НОВЕ ЗАМОВЛЕННЯ ДЗВІНКА

👤 Ім'я: Іван Петренко
📞 Телефон: +380 97 123 45 67

📅 Дата: 10.02.2025, 15:30:25

Сайт: Brokervn.com.ua
```

---

## 🔒 Безпека

**Важливо:**
- Не публікуйте Bot Token у відкритому доступі (GitHub, публічні репозиторії)
- Для продакшену рекомендується використовувати серверну частину (backend)
- FormSubmit безкоштовний, але має ліміт 50 відправок/день

**Альтернатива для продакшену:**
- Власний backend (Node.js, PHP, Python)
- Cloudflare Workers
- Netlify Functions
- Vercel Serverless Functions

---

## 🆘 Допомога

**Проблема:** Telegram не отримує повідомлення
- Перевірте Bot Token та Chat ID
- Переконайтеся що бот не заблокований
- Перевірте консоль браузера на помилки

**Проблема:** Email не приходить
- Перевірте спам/промоакції
- Підтвердіть email при першій відправці через FormSubmit
- Перевірте консоль браузера

**Проблема:** Помилка CORS
- FormSubmit підтримує CORS
- Для Telegram може знадобитися proxy або backend

---

## 📞 Контакти

- **Telegram для тестування:** https://t.me/SD983
- **Email:** brokervinnitsa@gmail.com
- **Телефон:** +380 97 698 46 80

**Розробка:** Broker_vn Website System
