# 🌐 Соціальні мережі та месенджери Broker_vn

## 📱 Активні посилання

### Facebook
- **URL:** https://facebook.com/brokervinnitsa
- **Опис:** Офіційна сторінка Facebook

### Instagram
- **URL:** https://instagram.com/broker_vn
- **Опис:** Офіційний Instagram профіль

### Telegram
- **URL:** https://t.me/SD983
- **Опис:** Telegram для зв'язку
- **Bot для сповіщень:** налаштовується окремо (див. TELEGRAM_EMAIL_SETUP.md)

### Viber
- **Варіант 1 (Використовується):** viber://chat?number=380976984680
  - Відкриває чат з номером
  - Працює на мобільних та desktop
  
- **Варіант 2 (Альтернатива):** https://connect.viber.com/business/e8ec3210-6c5c-11f0-bffd-aa2e6bf3418e
  - Business посилання
  - Для використання замініть в index.html рядок:
  ```html
  <a href="viber://chat?number=380976984680" class="social-item">
  ```
  на:
  ```html
  <a href="https://connect.viber.com/business/e8ec3210-6c5c-11f0-bffd-aa2e6bf3418e" class="social-item" target="_blank">
  ```

### WhatsApp
- **URL:** https://wa.me/380976984680
- **Опис:** Відкриває WhatsApp чат з номером +380 97 698 46 80
- **Формат:** wa.me без знаку "+" перед номером

### Email
- **URL:** mailto:brokervinnitsa@gmail.com
- **Опис:** Відкриває email клієнт для відправки листа

---

## 📞 Контактна інформація

- **Країна:** 🇺🇦 Україна
- **Місто:** 📍 Вінниця
- **Телефон:** +380 97 698 46 80
- **Email:** brokervinnitsa@gmail.com

---

## 🔗 Розташування посилань на сайті

### 1. Fixed Social Button (Кнопка справа внизу)
- Facebook
- Instagram  
- Telegram
- Viber
- WhatsApp
- Email

### 2. Footer (Підвал)
- Телефон: активне посилання `tel:+380976984680`
- Email: активне посилання `mailto:brokervinnitsa@gmail.com`

### 3. Consultation Form (Форма консультації)
- Кнопка "Зателефонувати зараз" → `tel:+380976984680`

---

## ⚙️ Налаштування в коді

### Зміна номера телефону

Якщо потрібно змінити номер, знайдіть та замініть в `index.html`:

```html
<!-- WhatsApp -->
<a href="https://wa.me/380976984680"

<!-- Viber -->
<a href="viber://chat?number=380976984680"

<!-- Footer телефон -->
<a href="tel:+380976984680">📞 +380 97 698 46 80</a>

<!-- Кнопка дзвінка в формі -->
<a href="tel:+380976984680" class="btn-phone">
```

### Зміна email

Знайдіть та замініть:

```html
<!-- Соцмережі -->
<a href="mailto:brokervinnitsa@gmail.com"

<!-- Footer -->
<a href="mailto:brokervinnitsa@gmail.com">✉️ brokervinnitsa@gmail.com</a>
```

В `js/script.js`:
```javascript
// FormSubmit email
await fetch('https://formsubmit.co/brokervinnitsa@gmail.com', {
```

---

## 🧪 Перевірка посилань

### Desktop:
- Facebook ✅ Відкривається в браузері
- Instagram ✅ Відкривається в браузері
- Telegram ✅ Відкривається Telegram Web або застосунок
- Viber ⚠️ Потребує встановленого Viber
- WhatsApp ✅ Відкривається WhatsApp Web або застосунок
- Email ✅ Відкриває email клієнт (Outlook, Gmail тощо)

### Mobile:
- Facebook ✅ Відкривається в додатку або браузері
- Instagram ✅ Відкривається в додатку або браузері
- Telegram ✅ Відкривається в додатку
- Viber ✅ Відкривається в додатку
- WhatsApp ✅ Відкривається в додатку
- Email ✅ Відкривається в додатку пошти

---

## 📊 Аналітика (опціонально)

Для відстеження кліків по соціальних мережах можна додати Google Analytics events:

```javascript
document.querySelectorAll('.social-item').forEach(item => {
    item.addEventListener('click', function() {
        const network = this.querySelector('span:last-child').textContent;
        gtag('event', 'social_click', {
            'event_category': 'Social',
            'event_label': network
        });
    });
});
```

---

## 🔄 Оновлення посилань

**Останнє оновлення:** 10.02.2025

Для оновлення посилань:
1. Відредагуйте `index.html`
2. Знайдіть секцію Social Menu
3. Оновіть `href` атрибути
4. Збережіть та протестуйте

---

**Broker_vn** - Професійне розмитнення авто 🚗
